#!/usr/bin/env bash

./../../tools/run_tovas.sh
sleep 30s
head -n 2000 ../tranco_Z38ZG.lst | ./../../tools/multi_query.py
for i in 1 2 3 4 5; do docker restart tova-$i; done;
sleep 10s
head -n 4000 ../tranco_Z38ZG.lst | tail -n 2000 | ./../../tools/multi_query.py
for i in 1 2 3 4 5; do docker restart tova-$i; done;
sleep 10s
head -n 6000 ../tranco_Z38ZG.lst | tail -n 2000 | ./../../tools/multi_query.py
for i in 1 2 3 4 5; do docker restart tova-$i; done;
sleep 10s
head -n 8000 ../tranco_Z38ZG.lst | tail -n 2000 | ./../../tools/multi_query.py
for i in 1 2 3 4 5; do docker restart tova-$i; done;
sleep 10s
head -n 10000 ../tranco_Z38ZG.lst | tail -n 2000 | ./../../tools/multi_query.py
